Put the Dune II PC data files here (from your own copy, version 1.07):
Tu wloz pliki danych Dune II z PC (z wlasnej kopii, wersja 1.07):
Hierher kommen die Dateien von Dune II f�r den PC (eigene Kopie, 1.07):

  ATRE.PAK  DUNE.PAK  ENGLISH.PAK  FINALE.PAK  HARK.PAK  MENTAT.PAK
  MERC.PAK  ORDOS.PAK  SCENARIO.PAK  SOUND.PAK  VOC.PAK
  (INTRO.PAK - only for the intro / tylko dla intro / nur f�r das Intro)

Step by step / krok po kroku / Schritt f�r Schritt:
doc/Install.txt (English, polski, Deutsch)

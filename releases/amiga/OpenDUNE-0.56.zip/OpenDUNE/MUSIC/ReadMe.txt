The music recordings go here (DUNE*_*.RAW, 34 files, about 75 MB;
AMIGA_19.RAW: the Amiga version's music, from its DUNEGAME.ENG in data).
Tu trafiaja nagrania muzyki (DUNE*_*.RAW, 34 pliki, ok. 75 MB;
AMIGA_19.RAW: muzyka z wersji Amiga, z jej DUNEGAME.ENG w data).

Make them once with MakeMusic (its icon in the OpenDUNE directory) from your
own game data in OpenDUNE/data. Without them the game runs without music.
Zrob je raz programem MakeMusic (ikona w katalogu OpenDUNE) z wlasnych
danych gry w OpenDUNE/data. Bez nich gra dziala bez muzyki.

Hierher kommen die Musikaufnahmen (34 Dateien, etwa 75 MB): einmal mit
MakeMusic (Icon in der Schublade OpenDUNE) aus deinen Spieldaten in
OpenDUNE/data aufnehmen. Ohne sie l�uft das Spiel ohne Musik.

Step by step / krok po kroku / Schritt f�r Schritt:
doc/Install.txt (English, polski, Deutsch)
